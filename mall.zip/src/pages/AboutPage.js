import BasicLayout from "../layout/BasicLayout";

function AboutPage (){

    return(
        <BasicLayout>
            <div className="mainPage">
                <h2>About Page</h2>
                <p>lorem</p>
            </div>
        </BasicLayout>
    )

}

export default AboutPage;

